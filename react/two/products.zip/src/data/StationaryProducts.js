const products = [{
  id: "1",
  name: "Pencil",
  price: 1,
  description: "Perfect for those who can't remember things! 5/5 Highly recommend."
},
{
  id: "2",
  name: "Housing",
  price: 0,
  description: "Housing provided for out-of-state students or those who can't commute"
}, {
  id: "3",
  name: "Computer Rental",
  price: 300,
  description: "Don't have a computer? No problem!"
}, {
  id: "4",
  name: "Coffee",
  price: 2,
  description: "Wake up!"
}, {
  id: "5",
  name: "Snacks",
  price: 0,
  description: "Free snacks!"
}, {
  id: "6",
  name: "Rubber Duckies",
  price: 3.50,
  description: "To help you solve your hardest coding problems."
}, {
  id: "7",
  name: "Fidget Spinner",
  price: 21.99,
  description: "Because we like to pretend we're in high school."
}, {
  id: "8",
  name: "Sticker Set",
  price: 14.99,
  description: "To prove to other devs you know a lot."
}
]
export default products