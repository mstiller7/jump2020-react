import React from 'react';

export default function Header() {
  var nameF = "Matthew";
  return <h1 className="header">Stationary Products by {nameF}</h1>
}