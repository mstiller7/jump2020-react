import React from 'react';

function MyInfo() {
  return (
    <div id="header">
      <h1>Matthew Stiller</h1>
      <p>
        I'm a software development major with various nerd interests.
        </p>
      <p>Top 3 vacation spots:</p>
      <ul>
        <li>Switzerland</li>
        <li>Oregon</li>
        <li>Texas</li>
      </ul>
    </div>
  );
}

export default MyInfo;