const jokes = [
  {
    "id": 0,
    "prompt": "Did you guys hear about the magic skillet?",
    "body": "It’s made of cast iron."
  },
  {
    "id": 1,
    "prompt": "How do you call a magician who’s incredibly good with cooking?",
    "body": "A sauceror."
  },
  {
    "id": 2,
    "prompt": "What's a courier's favorite type of armor?",
    "body": "Mail."
  },
  {
    "id": 3,
    "prompt": "A man walks into a bar. He takes 1d4 bludgeoning damage to the head."
  },
  {
    "id": 4,
    "prompt": "What do you call a raging giant?",
    "body": "Whatever he wants!"
  },
]
export default jokes;