import React from 'react';
import './styles.css';

import jokes from './data/jokes';
// import MyInfo from './components/MyInfo';



export default class App extends React.Component {

  // jokesCollection() {
  //   jokes.map(joke => {
  //     return (
  //       <Joke
  //         prompt={joke.prompt}
  //         body={joke.body}
  //       />
  //     )
  //   });
  // }
  
  render() {
    return (
      <div>
        <Header />
        {jokesCollection}
      </div>
    );
  }
}

class Joke extends React.Component {
  render() {
    return (
      [
        <p className="joke">{this.props.prompt}</p>,
        <p className="joke spoiler">{this.props.body && this.props.body}</p>
      ]
    );
  }
}

function Header() {
  var nameF = "Matthew";
  return <h1 className="header">Lame Joke Collection by {nameF}</h1>
}

const jokesCollection = jokes.map(joke => {
  return (
    <Joke
      prompt={joke.prompt}
      body={joke.body}
    />
  )
});